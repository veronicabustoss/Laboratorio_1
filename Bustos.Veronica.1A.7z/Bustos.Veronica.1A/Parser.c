#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "utn.h"
#include "Peliculas.h"

/** \brief  Cargara el archivo de texto pasado como parametro y lo guardara en una lista
 *
 * \param pFile FILE*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_PeliculasFromText(FILE* pFile , LinkedList* pArrayListEmployee)
{
    ePeliculas* auxiliarPeliculas = peliculas_new();
    int read;
    char idAux[50],nombreAux[50],anioAux[50],generoAux[20];
    int i = 0;
    if(pFile == NULL)
    {
        return -1;
    }
    //read = fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",idAux,nombreAux,anioAux,generoAux);
    while(!feof(pFile))
    {
        read = fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",idAux,nombreAux,anioAux,generoAux);
        if(read == 4)
        {
            auxiliarPeliculas = peliculas_newParametros(idAux,nombreAux,anioAux,generoAux);
            ll_add(pArrayListEmployee,auxiliarPeliculas);
            i ++;
        }
        else
            break;
    }

     printf("Se cargaron %d peliculas a la lista con exito !\n", i);
     return i;
}
