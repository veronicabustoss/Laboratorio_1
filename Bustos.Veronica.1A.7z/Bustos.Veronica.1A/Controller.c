#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "utn.h"
#include "Peliculas.h"
#include "Parser.h"


/** \brief Cargar en modo texto las peliculas
 *
 * \param path char*
 * \param this LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* this) //Le pasamos el archivo a leer y la lista
{
    int retorno = 0;
    FILE* fp = fopen( path, "r");

    if( fp != NULL && this != NULL)
    {
        parser_PeliculasFromText( fp, this);
        retorno = 1;
    }
    else
    {
        printf("El archivo no se pudo cargar.\n");
        fclose(fp);
    }
    fclose(fp);
    return retorno;
}

/** \brief Ordenar peliculas
 *
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortPeliculas(LinkedList* pArrayListEmployee)
{
    int retorno = 0;
    int opcion;
    if(pArrayListEmployee !=NULL)
    {
        printf("Ingrese la manera en que quiere ordenar las peliculas : \n");
        printf("1. Ordenar por Id descendente.\n");
        printf("2. Ordenar por Id ascendente.\n");
        scanf("%d", &opcion);
        switch(opcion)
        {
        case 1:
            ll_sort(pArrayListEmployee, peliculasSortById,0);
            printf("Ordenado con exito!!\n\n");
            break;
        case 2:
            ll_sort(pArrayListEmployee, peliculasSortById,1);
            printf("Ordenado con exito!!\n\n");
            break;
        default :
            printf("Se ha ingresado mal el dato.\n");
        }
        retorno = 1;
    }

    return retorno;
}

/** \brief Listar peliculas
 *
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListPeliculas(LinkedList* pArrayListEmployee)
{
    ePeliculas* pPeliculaAux;
    int retorno = 0;
    int largoLista = ll_len(pArrayListEmployee);
    int idAuxiliar;
    char nombreAuxiliar[200];
    int anioAuxiliar;
    char generoAuxiliar[128];
    int i;
    if(pArrayListEmployee!=NULL)
    {
        if(largoLista>0)
        {
            ///tengo todos los empleados cargados ya en una lista
            ///desde 0 hasta el largo de la lista
            ///ir recorriendo la lista, obteniendo cada empleado y mostrarlo
            printf("   Id      Nombre                           Anio             Genero\n");
            for(i = 0; i < largoLista; i++)
            {
                pPeliculaAux = (ePeliculas*)ll_get(pArrayListEmployee, i);
                peliculas_getId(pPeliculaAux, &idAuxiliar);
                peliculas_getNombre(pPeliculaAux,nombreAuxiliar);
                peliculas_getAnio(pPeliculaAux,&anioAuxiliar);
                peliculas_getGenero(pPeliculaAux,generoAuxiliar);
                printf("%5d %-40s %-15d %-15s\n",idAuxiliar, nombreAuxiliar, anioAuxiliar, generoAuxiliar);
               // mostrarEmpleado(pEmpleadoAux);
                /// algoritmo de guardado de pEmpleadoAux en archivo de texto
            }
            retorno = 1;
        }
        else
        {
            printf("No se cargaron los datos.\n");
        }

    }
    return retorno;
}


/** \brief Guarda los datos de las peliculas en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListPeliculas LinkedList*
 * \return int Retorno Devuelve 0 si esta mal, 1 si esta bien
 *
 */
int controller_saveAsTextFiltrada(char* path, LinkedList* pArrayListPeliculas)
{
    int retorno = 0;
    int largoLista = ll_len(pArrayListPeliculas);
    ePeliculas* pPeliculasAux;
    FILE* fp = fopen(path, "w");
    int i;
    if(fp==NULL)
    {
        printf("Error al abrir archivo para guardar\n");
        return retorno;
    }
    fprintf(fp, "id,nombre,anio,genero\n");
    if(pArrayListPeliculas!=NULL)
    {
        for(i = 0; i < largoLista; i++)
        {
            pPeliculasAux = (ePeliculas*)ll_get(pArrayListPeliculas, i);
            fprintf(fp, "%d,%s,%d,%s\n", pPeliculasAux->id, pPeliculasAux->nombre, pPeliculasAux->anio, pPeliculasAux->genero);
        }
        printf("Se ha realizado el guardado del archivo con exito !\n");
        retorno = 1;
    }
    fclose(fp);
    return retorno;
}

/** \brief Iniciara el Menu
 *
 * \return int
 *
 */
int Menu()
{
    int opcion;
    printf("----------- Bienvenido al menu ------------\n\n");
    printf("1) Cargar peliculas.\n");
    printf("2) Ordenar peliculas de forma ascendente por ID.\n");
    printf("3) Crear depurar peliculas.\n");
    printf("4) Funcion filter.\n");
    printf("5) Guardar archivos.\n");
    printf("6) Salir.\n");
    opcion = getValidInt("Ingrese la opcion que desea ejecutar: ","Error, dato no valido",1,6);
    return opcion;
}
