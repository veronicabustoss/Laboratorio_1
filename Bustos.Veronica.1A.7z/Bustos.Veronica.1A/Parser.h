
int parser_PeliculasFromText(FILE* pFile , LinkedList* pArrayListEmployee);
