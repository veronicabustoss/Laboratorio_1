
typedef struct
{
    int id;
    char nombre[200];
    int anio;
    char genero[128];

}ePeliculas;

ePeliculas* peliculas_new();

ePeliculas* peliculas_newParametros(char* idString, char* nombreString, char* anioString, char* generoString);

int peliculas_setId(ePeliculas* this, int id);

int peliculas_setNombre(ePeliculas* this, char* nombre);

int peliculas_setAnio(ePeliculas* this, int anio);

int peliculas_setGenero(ePeliculas* this, char* genero);

int peliculas_getId(ePeliculas* this, int *id);

int peliculas_getNombre(ePeliculas* this, char* nombre);

int peliculas_getAnio(ePeliculas* this, int *anio);

int peliculas_getGenero(ePeliculas* this, char *genero);

int peliculasSortById(void* peliculaA, void* peliculaB);

int depurarPeliculas(LinkedList* this);

int peliculasFiltradasAccion(void* pElement);
int peliculasFiltradasAventura(void* pElement);
int peliculasFiltradasDrama(void* pElement);
int peliculasFiltradasFantasia(void* pElement);
int peliculasFiltradasCienciaFiccion(void* pElement);
int peliculasFiltradasAnimacion(void* pElement);
int peliculasFiltradasComedia(void* pElement);
int peliculasFiltradasInfantil(void* pElement);

LinkedList* filtrarPeliculas(LinkedList* lista);
