
int controller_loadFromText(char* path, LinkedList* this);

int Menu();

int controller_sortPeliculas(LinkedList* pArrayListEmployee);

int controller_ListPeliculas(LinkedList* pArrayListEmployee);

int controller_saveAsTextFiltrada(char* path, LinkedList* pArrayListPeliculas);
