#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "utn.h"
#include "Peliculas.h"

/** \brief Reserva de memoria para la lista de peliculas
 *
 * \return ePeliculas*
 *
 */
ePeliculas* peliculas_new()
{
    ePeliculas* pPelicula = malloc(sizeof(ePeliculas));
    pPelicula->id = -1;
    strcpy(pPelicula->nombre,"");
    pPelicula->anio = 0;
    strcpy(pPelicula->genero,"");
    return pPelicula;
}


/** \brief Cargara las peliculas con los parametros
 *
 * \param idString char*
 * \param nombreString char*
 * \param anioString* char*
 * \param generoString char*
 * \return ePeliculas*
 *
 */
ePeliculas* peliculas_newParametros(char* idString, char* nombreString, char* anioString, char* generoString)
{
    ePeliculas* auxPeliculas = peliculas_new();
    if(auxPeliculas != NULL)
    {
        int id = atoi(idString);
        peliculas_setId(auxPeliculas,id);

        peliculas_setNombre(auxPeliculas,nombreString);

        int anio = atoi(anioString);
        peliculas_setAnio(auxPeliculas,anio);

        peliculas_setGenero(auxPeliculas,generoString);
    }

    return auxPeliculas;
}


/** \brief
 *
 * \param this ePeliculas*
 * \param id int
 * \return int
 *
 */
int peliculas_setId(ePeliculas* this, int id)
{
    int retorno = 0;
    if(this != NULL && id > 0)
    {
        this->id = id;
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param nombre char*
 * \return int
 *
 */
int peliculas_setNombre(ePeliculas* this, char* nombre)
{
    int retorno = 0;
    if(this != NULL && strlen(nombre)!= 0)
    {
        strcpy(this->nombre,nombre);
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param anio int
 * \return int
 *
 */
int peliculas_setAnio(ePeliculas* this, int anio)
{
    int retorno = 0;
    if(this != NULL && (anio > 0 && anio < 2020))
    {
        this->anio= anio;
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param sexo char
 * \return int
 *
 */
int peliculas_setGenero(ePeliculas* this, char* genero)
{
    int retorno = 0;
    if(this != NULL && genero != NULL)
    {
        strcpy(this->genero,genero);
        retorno =  1;
    }
    return retorno;
}

///------------------------------ GET -----------------------------

/** \brief
 *
 * \param this ePeliculas*
 * \param id int*
 * \return int
 *
 */
int peliculas_getId(ePeliculas* this, int *id)
{
    int retorno = 0;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param nombre char*
 * \return int
 *
 */
int peliculas_getNombre(ePeliculas* this, char* nombre)
{
    int retorno = 0;
    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre,this->nombre);
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param anio int*
 * \return int
 *
 */
int peliculas_getAnio(ePeliculas* this, int *anio)
{
    int retorno = 0;
    if(this != NULL && anio != NULL)
    {
        *anio = this->anio;
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param this ePeliculas*
 * \param genero char*
 * \return int
 *
 */
int peliculas_getGenero(ePeliculas* this, char *genero)
{
    int retorno = 0;
    if(this != NULL && genero != NULL)
    {
        strcpy(genero,this->genero);
        retorno =  1;
    }
    return retorno;
}

/** \brief Ordenara a las peliculas  basandose en el Id
 *
 * \param peliculaA void*
 * \param peliculaB void*
 * \return int
 *
 */
int peliculasSortById(void* peliculaA, void* peliculaB)
{
    int retorno;

    ePeliculas* peliA;
    ePeliculas* peliB;

    if((peliculaA != NULL )&& (peliculaB != NULL))
    {
        peliA = (ePeliculas*) peliculaA;
        peliB = (ePeliculas*) peliculaB;
        if(peliA->id == peliB->id)
        {
            retorno = 1;
        }
        if(peliA->id > peliB->id)
        {
            retorno = -1;
        }
        if(peliA->id < peliB->id)
        {
            retorno = 0;
        }
    }

    return retorno;
}

/** \brief Generara peliculas
 *
 * \param this LinkedList*
 * \return int
 *
 */
int depurarPeliculas(LinkedList* this)
{
    int retorno=0;
    void* elementoA;
    void* elementoB;
    ePeliculas* peliculaA;
    ePeliculas* peliculaB;
    int i;
    int j;
    char conexion[100];
    if(this!=NULL)
    {
        for(i=0; i<ll_len(this); i++)
        {
            strcpy(conexion,"|");
            elementoA=ll_get(this,i);
            peliculaA = (ePeliculas*) elementoA;
            for(j=i+1; j<ll_len(this); j++)
            {
                elementoB=ll_get(this,j);
                peliculaB = (ePeliculas*) elementoB;
                if(strcmp(peliculaA->nombre,peliculaB->nombre)==0)
                {
                    strcpy(conexion,"|");
                    strcat(conexion,peliculaB->genero);
                    strcat(peliculaA->genero,conexion);
                    ll_remove(this,j);
                    j--;
                }
            }
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de accion
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasAccion(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Accion") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de aventura
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasAventura(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Aventura") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de drama
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasDrama(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Drama") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}


/** \brief Filtrara solo los generos de fantasia
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasFantasia(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Fantasia") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de animacion
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasAnimacion(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Animacion") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de comedia
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasComedia(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Comedia") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}

/** \brief Filtrara solo los generos de ciencia ficcion
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasCienciaFiccion(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Ciencia ficcion") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}


/** \brief Filtrara solo los generos infantiles
 *
 * \param pElement void*
 * \return int
 *
 */
int peliculasFiltradasInfantil(void* pElement)
{
    int retorno = 0;
    ePeliculas* empleado;
    if(pElement != NULL)
    {
        empleado = (ePeliculas*)pElement;
        if(strcmp(empleado->genero, "Infantil") == 0) //Si el nombre de la lista coincide, retornaa 1
        {
            retorno = 1;
        }
    }
    return retorno;
}


/** \brief Filtrara por cierto criterio la pelicula pasada como parametro
 *
 * \param lista LinkedList*
 * \return LinkedList*
 *
 */
LinkedList* filtrarPeliculas(LinkedList* lista)
{
    system("cls");
    LinkedList* peli;
    int opcion;
    printf("Ingrese la forma en que desea filtrar las peliculas: \n");
    printf("1- Accion\n");
    printf("2- Aventura\n");
    printf("3- Drama\n");
    printf("4- Infantil\n");
    printf("5- Comedia\n");
    printf("6- Ciencia ficcion\n");
    printf("7- Fantasia\n");
    printf("8- Animacion\n");
    opcion = getValidInt("Ingrese la ipcion que desea filtrar: ","Error, ingrese nuevamente: ",1,8);
    switch(opcion)
    {
    case 1:
        peli = ll_filter(lista,peliculasFiltradasAccion);
        printf("Filtrado con exito!!\n");
        break;
    case 2:
        peli = ll_filter(lista,peliculasFiltradasAventura);
        printf("Filtrado con exito!!\n");
        break;
    case 3:
        peli = ll_filter(lista,peliculasFiltradasDrama);
        printf("Filtrado con exito!!\n");
        break;
    case 4:
        peli = ll_filter(lista,peliculasFiltradasInfantil);
        printf("Filtrado con exito!!\n");
        break;
    case 5:
        peli = ll_filter(lista,peliculasFiltradasComedia);
        printf("Filtrado con exito!!\n");
        break;
    case 6:
        peli = ll_filter(lista,peliculasFiltradasCienciaFiccion);
        printf("Filtrado con exito!!\n");
        break;
    case 7:
        peli = ll_filter(lista,peliculasFiltradasFantasia);
        printf("Filtrado con exito!!\n");
        break;
    case 8:
        peli = ll_filter(lista,peliculasFiltradasAnimacion);
        printf("Filtrado con exito!!\n");
        break;
    }

    return  peli;
}
