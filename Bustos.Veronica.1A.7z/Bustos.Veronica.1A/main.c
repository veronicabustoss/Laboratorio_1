#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "utn.h"
#include "Peliculas.h"
#include "Parser.h"
#include "Controller.h"

int main()
{

    int opcion;
    LinkedList* listaPeliculas = ll_newLinkedList();
    LinkedList* listaDepurada = ll_newLinkedList();
    LinkedList* listaFiltrada = ll_newLinkedList();
    int flag = 0;
    int flag2 = 0;
    int flag3 = 0;
    char path[20];
    do
    {
        opcion = Menu();
        switch(opcion)
        {
        case 1:
            printf("\nIngrese el archivo que desea abrir (recuerde que termina con .csv): ");
            fflush(stdin);
            gets(path);
            flag = controller_loadFromText(path,listaPeliculas);
                        system("pause");
            system("cls");
            flag2 =controller_loadFromText(path,listaDepurada);
            flag3 = controller_loadFromText(path,listaFiltrada);
            system("cls");

            break;
        case 2:
            if(flag == 1 )
            {
                           ll_sort(listaPeliculas,peliculasSortById,0);
            controller_ListPeliculas(listaPeliculas);
            }
            else
            {
                printf("No se pudo ordenar, compruebe haber cargado el archivo\n");
            }
           // controller_sortPeliculas(listaPeliculas);

            system("pause");
            system("cls");
            break;
        case 3:
            if(flag == 1)
            {
                            depurarPeliculas(listaDepurada);
            controller_ListPeliculas(listaDepurada);
            }
            else
            {
                printf("Error al depurar la lista de peliculas, compruebe si se abrio el archivo correctamente.\n");
            }

            system("pause");
            system("cls");
            break;
        case 4:
            if(flag == 1)
            {

                            listaFiltrada = filtrarPeliculas(listaPeliculas);
            }
            else
            {
                printf("Error al filtrar la lista de peliculas, compruebe si se abrio el archivo correctamente.\n");
            }

            system("pause");
            system("cls");
            break;
        case 5:
            if(flag == 1 && flag2 == 1 && flag3 == 1)
            {
                            controller_saveAsTextFiltrada("depurado.csv",listaDepurada);
            controller_saveAsTextFiltrada("filtrado.csv",listaFiltrada);
            }
            else
            {
                printf("Error, no se pudo guardar las listas.\n");
            }

            system("pause");
            system("cls");
            break;
        case 6:

            printf("\n�Gracias por usar el menu!");
            system("pause");
            system("cls");

            break;
        default:
            printf("Dato no valido, ingrese nuevamente.\n");
        }


    }
    while(opcion != 6);

    return 0;
}
